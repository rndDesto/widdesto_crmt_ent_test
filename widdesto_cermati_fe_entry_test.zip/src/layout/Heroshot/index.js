import { withStyles } from '@material-ui/core';
import useStyle from './style';
import Component from './Heroshot';

export default withStyles(useStyle)(Component);

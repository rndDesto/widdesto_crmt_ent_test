import { withStyles } from '@material-ui/core';
import useStyle from './style';
import Component from './Newsletter';

export default withStyles(useStyle)(Component);

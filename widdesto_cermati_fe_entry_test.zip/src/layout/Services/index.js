import { withStyles } from '@material-ui/core';
import useStyle from './style';
import Component from './Services';

export default withStyles(useStyle)(Component);

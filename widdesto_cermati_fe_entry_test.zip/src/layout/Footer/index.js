import { withStyles } from '@material-ui/core';
import useStyle from './style';
import Component from './Footer';

export default withStyles(useStyle)(Component);

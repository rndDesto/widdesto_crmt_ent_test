const useStyle = (theme) => ({
    'footerBg':{
        'background':'#050328',
        'color': '#AEC5FF',
        'padding': theme.spacing(5)
    },
});

export default useStyle;



